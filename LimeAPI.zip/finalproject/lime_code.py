# import the necessary packages:
# requests: known as HTTP for Humans (http://docs.python-requests.org/en/master/)
# psycopg2: a PostgreSQL adapter for python (http://initd.org/psycopg/)
# json: encodes and decodes json
# sys: system specific parameters

import requests
import psycopg2
import json
import sys

# create variable that uses package to connect to my local database.
conn = psycopg2.connect(database='postgres', user='postgres', password='postgres', host='localhost', port='5432')
# with a connection to the db, I can create a cursor object to perform sql commands.
cur = conn.cursor()
# Lime api authorization and request for data
headers = {'Authorization': 'Bearer limebike-yaAXxjtJHLcbUat'}
r = requests.get('https://lime.bike/api/partners/v1/gbfs_secure/st_paul/free_bike_status.json ', headers=headers)

# parses through the json data to grab the needed data, assigns it to a
# variable and prints out the number of rows to be inserted.
json_data = r.json()
formatted_points = json_data['data']['bikes']
print ('There are %d total rows to be inserted' %len(formatted_points))

# create a list of available fields from Lime API
fields = [
    'bike_id',
    'is_disabled',
    'is_reserved',
    'lon',
    'lat',
    'vehicle_type'
    ]

print('Current Lime API data to be inserted into database and copied into the resultsfile.csv')
print('\n')

# For loop that looks inside the variable with the current data and
# creates a new variable by assigning it to the appropriate available field.
# Lastly, the execute method is performed in the database by inserting the
# values from each of the different fields into the previously created table
# 'shared_bikes_lime' in pgAdmin. A point is also made from the lat & lon using
# st_point and inserted into the 'geom' field.
for item in formatted_points:
    my_data = [item[field] for field in fields]
    print(my_data)
    query = cur.execute("INSERT INTO shared_bikes_lime (bike_id, is_disabled, is_reserved, geom, vehicle_type) VALUES (%s, %s, %s, ST_SetSRID(ST_Point(%s, %s),4326), %s)", my_data)

# new variable is created from the results of the previous insert statement.
# A new query is run on the results from the 'shared_bikes_lime' table so
# that it will write all results (including the timestamp that pgAdmin added)
# to a sample dataset csv file called 'resultsfile.csv'.
outquery = "COPY shared_bikes_lime TO STDOUT WITH CSV HEADER".format(query)
with open('resultsfile.csv', 'w') as f:
    cur.copy_expert(outquery, f)

# closes database connection.
conn.commit()
cur.close()
conn.close()
