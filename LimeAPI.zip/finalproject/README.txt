####################################################################
#                                                                  #
#    ##    ##      ##   ##    #####        ####     #####   ##     #
#    ##    ##     #### ####   ##          ##  ##    ##  ##  ##     #
#    ##    ##    ##  ##   ##  #####      ########   #####   ##     #
#    ##    ##   ##   ##    ## ##        ##      ##  ##      ##     #
#    ####  ##   ##   ##    ## #####    ##        ## ##      ##     #
#                                                                  #
####################################################################

# By: Nicole Helgeson

### Introduction ###
Lime scooters/bikes have made an appearance in St. Paul (and Minneapolis) in 2018 and while it seems like there is high demand, there isn't much information about how people have been using them. This project collects Lime scooter and bike data over a period of time using the API and then analyzes how people are riding in St. Paul. 

### Installation ###
No installation is needed. Simply open the LimeAPI.ipynb file in jupyter notebook

### Running the Code ###
Since the original data and API key are not included due to security reasons, the code has already been run in jupyter notebook and should automatically display. Running the code will produce an error.

### Bugs/Issues ###
The City of St. Paul has access to and owns the data, therefore, for security reasons there are a few things that are not included and may produce errors in the .ipynb file.

1. Database - the data was created and stored locally in a postgresql database. This was not included.
2. The data that was produced from calling the API (resultsfile.csv) was not included.
3. The API access key was removed so the code that calls the API will not work.
4. The maps and graphs that were produced from the code may or may not display when the .ipynb file is loaded. Screenshots of these are included in the .ipynb file and can be found in the 'figures' folder in case there are issues.

